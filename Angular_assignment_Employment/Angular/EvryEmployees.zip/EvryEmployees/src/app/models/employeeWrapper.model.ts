import { Employee } from './employee.model';

export  class EmployeeWrapper{

    employee:Employee;
}