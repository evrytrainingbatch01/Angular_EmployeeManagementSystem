export class EmployeeBasicDetails
{
    fullName:string;
    dateOfBirth:string;
    email:string;
    mobile:string;
    employeeType:string;
}