export class EmployeeMoreDetails{

    constructor(){}

    hireDate:string;
    gender:string;
    department:string;
    address:string;
    maritalStatus:string;
    

}