import { Employee } from './employee.model';

export class EmployeeResponseWrapper{

    employeeList:Employee[]=Array();
    

}