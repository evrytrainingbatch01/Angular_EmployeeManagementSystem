export class EmployeeIds{

    employeeIds:number[];
}