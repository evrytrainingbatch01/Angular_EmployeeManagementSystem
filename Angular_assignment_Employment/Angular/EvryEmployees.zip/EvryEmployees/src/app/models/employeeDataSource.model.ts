export class EmployeeDataSource{

    constructor(){
        
    }
    id:string;
    fullName:string;
    dateOfBirth:String;
    email:string;
    mobile:string;
    employeeType:string;
    hireDate:String;
    gender:string;
    department:string;
    address:string;
    jobLocation:string;
}