import { DigitOnlyDirective } from './digit-only.directive';

describe('DigitOnlyDirective', () => {
  it('should create an instance', () => {
    const directive = new DigitOnlyDirective();
    expect(directive).toBeTruthy();
  });
});
