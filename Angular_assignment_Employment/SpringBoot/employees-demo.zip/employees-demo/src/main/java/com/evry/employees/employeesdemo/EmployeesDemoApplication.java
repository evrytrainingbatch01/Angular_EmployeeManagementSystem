package com.evry.employees.employeesdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeesDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeesDemoApplication.class, args);
	}

}
