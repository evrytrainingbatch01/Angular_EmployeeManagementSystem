package com.evry.employees.employeesdemo.model;

public class EmployeeIds {
	
	int[] employeeIds;

	public int[] getEmployeeIds() {
		return employeeIds;
	}

	public void setEmployeeIds(int[] employeeIds) {
		this.employeeIds = employeeIds;
	}

}
