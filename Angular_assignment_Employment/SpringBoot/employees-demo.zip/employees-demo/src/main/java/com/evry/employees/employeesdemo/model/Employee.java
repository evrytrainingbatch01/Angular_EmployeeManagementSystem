package com.evry.employees.employeesdemo.model;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Employees")
public class Employee {
	
	@Id
	@Column(name="Employee_Id")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	
	@Embedded
	private EmployeeBasicDetails employeeBasicDetails;
	
    @Embedded
	private EmployeeMoreDetails employeeMoreDetails;
	
	public EmployeeBasicDetails getEmployeeBasicDetails() {
		return employeeBasicDetails;
	}
	public void setEmployeeBasicDetails(EmployeeBasicDetails employeeBasicDetails) {
		this.employeeBasicDetails = employeeBasicDetails;
	}
	public EmployeeMoreDetails getEmployeeMoreDetails() {
		return employeeMoreDetails;
	}
	public void setEmployeeMoreDetails(EmployeeMoreDetails employeeMoreDetails) {
		this.employeeMoreDetails = employeeMoreDetails;
	}
	
}
