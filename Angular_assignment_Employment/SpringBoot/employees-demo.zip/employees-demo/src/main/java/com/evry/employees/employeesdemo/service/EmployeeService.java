package com.evry.employees.employeesdemo.service;

import java.util.List;

import com.evry.employees.employeesdemo.model.Employee;
import com.evry.employees.employeesdemo.model.EmployeeIds;

public interface EmployeeService {
	
	public Employee addEmployee(Employee  employee);
	public List<Employee> getEmployeeList();
	public boolean deleteEmployee(int id);
	public boolean editEmployee(Employee employee);
	public boolean deleteEmployees(EmployeeIds employeeIds);

}
