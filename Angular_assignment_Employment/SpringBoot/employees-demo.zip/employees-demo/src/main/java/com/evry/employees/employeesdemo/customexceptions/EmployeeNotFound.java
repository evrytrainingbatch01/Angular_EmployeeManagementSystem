package com.evry.employees.employeesdemo.customexceptions;

public class EmployeeNotFound extends RuntimeException {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -3118208335381835591L;

	public EmployeeNotFound(String message)
	{
		super(message);
	}

}
